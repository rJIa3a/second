hit_field_list = [
    "ym:pv:date",
    "ym:pv:dateTime",
    "ym:pv:URL",
    "ym:pv:deviceCategory",
    "ym:pv:operatingSystemRoot",
    "ym:pv:clientID",
    "ym:pv:browser",
    "ym:pv:lastTrafficSource",
    "ym:pv:goalsID",
    "ym:pv:parsedParamsKey1",
    "ym:pv:parsedParamsKey2"
]

visit_field_list = [
    "ym:s:date",
    "ym:s:dateTime",
    "ym:s:pageViews",
    "ym:s:visitDuration",
    "ym:s:startURL",
    "ym:s:deviceCategory",
    "ym:s:operatingSystemRoot",
    "ym:s:clientID",
    "ym:s:browser",
    "ym:s:browserEngine",
    "ym:s:screenOrientation",
    "ym:s:screenWidth",
    "ym:s:screenHeight",
    "ym:s:physicalScreenWidth",
    "ym:s:physicalScreenHeight",
    "ym:s:lastTrafficSource",
    "ym:s:purchaseRevenue",
    "ym:s:purchaseID",
    "ym:s:bounce",
    "ym:s:isNewUser",
    "ym:s:goalsID"
]
